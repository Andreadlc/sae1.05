

                function myFunction() {
                  var x = document.getElementById("mobileMenu");
                  if (x.className === "mobile-menu") {
                    x.className += " responsive";
                  } else {
                    x.className = "mobile-menu";
                  }
                }





  document.addEventListener("DOMContentLoaded", function () {
    var gifIcons = document.querySelectorAll(".gif-icon");

    gifIcons.forEach(function (icon) {
      var gifPath = icon.getAttribute("data-gif");
      var staticPath = icon.getAttribute("src");

      icon.addEventListener("mouseenter", function () {
        icon.setAttribute("src", gifPath);
      });

      icon.addEventListener("mouseleave", function () {
        icon.setAttribute("src", staticPath);
      });
    });
  });

function getHU()
{
  var hu = document.getElementById("hu").value; 
 alert(hu);
}

function RedirectionTabnul(){
   var hu = document.getElementById("hu").value;
  if (hu =="2023")
    document.location.href="page3.html#table"; 
  else if (hu=="2024")
    document.location.href="page3 2024.html#table"
  else if (hu=="2025")
    document.location.href="page3 2025.html#table"
  else if (hu=="2026")
    document.location.href="page3 2026.html#table"
}

function RedirectionTab(){
  var hu = document.getElementById("hu").value;
  if (hu =="2023")
    window.location.replace("page3.html#espace-planning"); 
  else if (hu=="2024")
    window.location.replace("page3 2024.html#espace-planning");
  else if (hu=="2025")
    window.location.replace("page3 2025.html#espace-planning");
  else if (hu=="2026")
    window.location.replace("page3 2026.html#espace-planning");
}

function RedirectionTabtest(){
  var hu = document.getElementById("hu").value;
  if (hu =="2023")
    window.location.replace("test.html"); 
  else if (hu=="2024")
    window.location.replace("test2.html");
  else if (hu=="2025")
    window.location.replace("test3.html");
  else if (hu=="2026")
    window.location.replace("test4.html");
  else 
    window.location.replace("index.html");
}
